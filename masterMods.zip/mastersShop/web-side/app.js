var value = 0

$(document).ready(function(){
	window.addEventListener("message",function(event){

		if (event["data"]["action"] !== undefined){
			if (event["data"]["action"] == true){
                $("body").show()
				$("#container").fadeIn(500);
                $("body").fadeIn(500);
                var html2 = $(`<span id="title">`+ event.data.onamewa +`</span> <span id="sifro">$</span><span id="price">0</span> <div style="display: inline-block;" class="rec-cart" id="rec-cart`+event.data.i+`"> <img src="images/cart.png"> </div>`)
                $("#header").append(html2);


                $("#rec-cart"+event.data.i + "").click(function(){
                    if (value >= 1){    
                    mta.triggerEvent('buy', event.data.n, event.data.price, event.data.price, event.data.index)
                    }
                })

			} else {
				$("#container").fadeOut(500);
                $("body").fadeOut(500);
                $("body").hide()
			}

			return
		}
    });

    window.addEventListener("message",function(event){
    if (event["data"]["update"] !== undefined){
        if (event["data"]["update"] == true){

        var count = 0


        var html = $(`
        
            <div class="iten" id="iten`+event.data.n+`">
            <div class="tudo">
            <h1 id="price-iten" class="price-iten">$ `+ event.data.price + `</h1>
            <img id="iten" src="images/` + event.data.img + `">
            <h1 class="iten-name" id="iten-name">`+ event.data.name + `</h1>
            <div class="controls">
                <div style="display: inline-block;" class="menos" id="menos` + event.data.n + `" > &lt </div>
                <div style="display: inline-block;" class="qtd" id="qtd` + event.data.n + `"> 0 </div>
                <div style="display: inline-block;" class="mais" id="mais` + event.data.n + `"> &gt </div>
            </div>
            </div>
        </div>
            
        `)



        $("#price").html("0")


        $("#title").html(event.data.onamewa)
        $("#Itens").append(html);


        $(`#mais` + event.data.n + ``).click(function(){
            count = count + 1
            value = value + event.data.price
            $("#price").html( Number($("#price").html()) + event.data.price )
            var qtd = $("#qtd" + event.data.n + "").html(count)
            mta.triggerEvent('addItem', event.data.n, event.data.name, count, event.data.price, event.data.index)
        })

        $(`#menos` + event.data.n + ``).click(function(){
        if (count >= 1 & value >= 1){
            count = count - 1
            value = value - event.data.price
            $("#price").html( Number($("#price").html()) - event.data.price )
            var qtd = $("#qtd" + event.data.n + "").html(count)
            mta.triggerEvent('removeItem', event.data.n, event.data.name, count, event.data.price, event.data.index)
        }
        })








        } else {
            $("#Itens").html('')
            $("#header").html('');
        }
        
    }
})

});