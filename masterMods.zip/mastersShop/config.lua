Config = { -- 1194.9375,-1315.6596679688,13.3984375

    ["info"] = function(player, msg)
        triggerClientEvent(player, "Notify", player, "azul", msg)
    end,

    ["infoC"] = function(player, msg)
        triggerEvent( "Notify", player, "azul", msg)
    end,

    Shops = {   
        ["supermarket"] = {
            Nome = "24/7 SUPERMARKET",
            Position = {1186.3798828125,-1316.6071777344,13.557317733765 -1, "cylinder", 2.0, 255, 100, 100, 255 },
            Dim = 0,
            Int = 0,
            Itens = {
                [2] = {"Agua", 1000, "Agua", "water.png"}, -- o primeiro sempre vai começar como [2]
                [3] = {"Cerveja", 1000, "Cerveja", "water.png"},
                [4] = {"Energético", 50, "Energético", "energetic.png"},
            },
        },


    }
}