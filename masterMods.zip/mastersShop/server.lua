for i, v in pairs(Config.Shops) do

    marker = createMarker(v.Position[1], v.Position[2], v.Position[3], v.Position[4], v.Position[5], v.Position[6],v.Position[7],v.Position[8],v.Position[9])
    setElementInterior(marker, v.Int)
    setElementDimension(marker, v.Dim)
    addEventHandler("onMarkerHit", marker, 
    function(player)

        triggerClientEvent(player, 'openShop', player, v.Itens, v.Nome, i)

    end)

end

addEvent('takeMoney', true)
addEventHandler('takeMoney', getRootElement(), function(player, amount)
    takePlayerMoney(player, amount)
end)


addEvent('invN3xt', true)
addEventHandler('invN3xt', getRootElement(), function(player, table, quantia)
    local mochila = false
    for i, v in pairs(table) do
        if tonumber(v[4]) > 0 then 
        local qtd = tonumber(v[4])
        if (exports.n3xt_inventario:getSpaceMochila(player, v[3], qtd) == true) then
            exports.n3xt_inventario:giveItem( player, v[3], qtd )
        else
            mochila = true
        end
     end
    end

     if mochila == false then 
        takePlayerMoney(player, quantia)
        Config["info"](player, "Você comprou os itens com sucesso..")
     else
        Config["info"](player, "Você não tem espaço o suficiente.")
     end
end)