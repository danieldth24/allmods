local x, y = guiGetScreenSize()
local link = "http://mta/"..getResourceName(getThisResource()).."/web-side/index.html"
local browser = createBrowser(x, y, true, true, false)
local openned = false
local count = 0
local itens = {}


addEventHandler("onClientBrowserCreated", browser, function()
    loadBrowserURL(source, link)
    focusBrowser(browser)
 end)


 
 
 function SendNUIMessage(browser, table)
    if isElement(browser) and type(table) == "table" then
       return executeBrowserJavascript(browser, 'window.postMessage('..toJSON(table)..'[0])')
    end
 end


 function dxNUI()

    dxDrawImage(0, 0, x, y, browser)


end

addEvent('openShop', true)
addEventHandler('openShop', getRootElement(), function(tabela, name, i)
   if (openned == false) then
      addEventHandler('onClientRender', getRootElement(), dxNUI) 
      SendNUIMessage(browser, {action = true, onamewa = name, i = i})
      itens = {}
      count = 0

      for i, v in pairs(tabela) do 

         SendNUIMessage(browser, {update = true, n = i, name = v[1], price = v[2], index = v[3], img = v[4] })
         showCursor(true)

      end
      openned = true
   else
      removeEventHandler('onClientRender', getRootElement(), dxNUI) 
      SendNUIMessage(browser, {action = false})
      openned = false
      SendNUIMessage(browser, {update = false})
      showCursor(false)
   end

end)

bindKey('backspace', 'down', function()

   if (openned == true) then 
      removeEventHandler('onClientRender', getRootElement(), dxNUI) 
      SendNUIMessage(browser, {action = false})
      SendNUIMessage(browser, {update = false})
      openned = false
      showCursor(false)
   end
end)

addEvent('addItem', true)
addEventHandler('addItem', getRootElement(), function(i, name, qtd, price, index)

    count = count + price,
    table.insert(itens, i, {name, tonumber(price), index, qtd} )
    iprint(itens)


end)

addEvent('removeItem', true)
addEventHandler('removeItem', getRootElement(), function(i, name, qtd, price, index)

    count = count - price
    table.insert(itens, i, {name, tonumber(price), index, qtd} )

end)




addEvent('buy', true)
addEventHandler('buy', getRootElement(), function()
   
   local money = getPlayerMoney(localPlayer)
   if money >= count then
         triggerServerEvent('invN3xt', localPlayer, localPlayer, itens, count )
      else
         Config["infoC"](localPlayer, "Você não tem dinheiro suficiente.")
      end
end)


addEventHandler("onClientBrowserCreated", browser, function()
   loadBrowserURL(source, link)
   addEventHandler("onClientKey", root, onKey)
end)



addEventHandler("onClientCursorMove", root,
   function (relativeX, relativeY, absoluteX, absoluteY)
       injectBrowserMouseMove(browser, absoluteX, absoluteY)
   end
)


addEventHandler("onClientClick", root,
   function(button, state)
       if state == "down" then
           injectBrowserMouseDown(browser, button)
       else
           injectBrowserMouseUp(browser, button)
       end
   end
)


function onKey(button)
   if button == "mouse_wheel_down" then
       injectBrowserMouseWheel(browser, -90, 0)
   elseif button == "mouse_wheel_up" then
       injectBrowserMouseWheel(browser, 90, 0)
   end
end