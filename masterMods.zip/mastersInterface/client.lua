local x, y = guiGetScreenSize()
local link = "http://mta/"..getResourceName(getThisResource()).."/web-side/index.html"
local browser = createBrowser(x, y, true, true, false)


addEventHandler("onClientBrowserCreated", browser, function()
   loadBrowserURL(source, link)
end)


function SendNUIMessage(browser, table)
   if isElement(browser) and type(table) == "table" then
      return executeBrowserJavascript(browser, 'window.postMessage('..toJSON(table)..'[0])')
   end
end

local expIncrease = 125
local maxLevel = 1000
local maxExp  = maxLevel*expIncrease

function getPlayerExperienceByLevel(player)
    local levelCurrent = tonumber(getElementData(player, "Level")) or 1
    return levelCurrent*expIncrease
end

function dxNUI()

    dxDrawImage(0, 0, x, y, browser)

    local health = getElementHealth(localPlayer)
    local armour = getPlayerArmor(localPlayer)

    local fome = getElementData( localPlayer, ElementDataFome) or 100
    local level = getElementData( localPlayer, ElementDataLevel) or 100
    local xp = getElementData( localPlayer, ElementDataXp) or 1000

    local time = getRealTime()
    hour = time.hour
    minute = time.minute

    local x,y,z = getElementPosition(localPlayer)

    local street = getZoneName ( x, y, z, false )



    if isPedInVehicle(localPlayer) then
        local veh = getPedOccupiedVehicle(localPlayer)
        local cinto = getElementData(localPlayer, 'cinto') or false
        local gas = getElementData(veh, 'gas') or 100
        local door = getVehicleDoorOpenRatio (veh, 2)
        local dorozo = false
        local light = getVehicleOverrideLights ( veh )
        local luzoro = false
        local motor = getVehicleEngineState ( veh )

        if tonumber(door) == 1 then 
            dorozo = true
        else
            dorozo = false
        end


        if light == 2  then 
            luzoro = true
        else
            luzoro = false
        end


        local velocity = ( function( x, y, z ) return math.floor( math.sqrt( x*x + y*y + z*z ) * 155 ) end )( getElementVelocity( getPedOccupiedVehicle(localPlayer) ) ) 
        
        SendNUIMessage(browser, {hud = true, hour = hour, street = street,  minute = minute, explvl = getPlayerExperienceByLevel(localPlayer), exp = xp, level = level, porta = dorozo, motor = motor, gas = gas, luz = luzoro, car = true, speed = velocity, health = health, armour = armour, fome = fome, sede = sede})
    else
        SendNUIMessage(browser, {hud = true, hour = hour, minute = minute, street = street, explvl = getPlayerExperienceByLevel(localPlayer), exp = xp, level = level, health = health, armour = armour, fome = fome, sede = sede})
    end

end
addEventHandler('onClientRender', getRootElement(), dxNUI) 




