$(document).ready(function(){
	window.addEventListener("message",function(event){

        var data = event.data;

        $("#health_bar").css("width", 125 /  100 * data.health +"px" )

        $("#armour_bar").css("width", 125 /  100 * data.armour +"px" )

        $("#fome_bar").css("width", 125 /  100 * data.fome +"px" )

        $("#fome_bar").css("width", 125 /  100 * data.fome +"px" )
        $("#spanlevel").html(data.level)

        var expIncrease = 125
        var maxLevel = 1000
        var maxExp  = maxLevel*expIncrease

        function getPlayerExperienceByLevel(){
            var levelCurrent = tonumber(data.level)
            return levelCurrent*expIncrease
        }


        $("#levle").css("height", 125 /  data.explvl * data.exp +"px" )

        $(".city").html(data.street)

        $(".hour").html(data.hour + ":" + data.minute)

        

        if (data.car === true){
            $("#gasosa").css("height", 11 /  100 * data.gas +"px" )

            if ( data.speed >= Number(100) ){
                $(".pitoquinho").css("left", "95%")
            } else {
                $(".pitoquinho").css("left", data.speed + "%")
            }

            if ( data.porta === true ){
                $("#door").attr('src', 'imgs/door_active.png');
            } else {
                $("#door").attr('src', 'imgs/door.png');
            }


            if ( data.luz === true ){
                $("#luz").attr('src', 'imgs/farol_active.png');
            } else {
                $("#luz").attr('src', 'imgs/farol.png');
            }


            if ( data.motor === true ){
                $("#motor").attr('src', 'imgs/motor_active.png');
            } else {
                $("#motor").attr('src', 'imgs/motor.png');
            }


            $("#velo").css("display", "block")

            if (Number(data.speed) <= 9) {
                $("#veloogfvsd").html("00"+data.speed)
                
            } else if (Number(data.speed) <= 99) {
                    $("#veloogfvsd").html("0"+data.speed)
                
            } else {
                $("#veloogfvsd").html(""+data.speed)
            }




        } else {
            $("#velo").css("display", "none")
        }

    })
})