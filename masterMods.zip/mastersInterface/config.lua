ElementDataFome = "hunger"
ElementDataLevel = "Level"
ElementDataXp = "Experience"