addCommandHandler('avisoadm', function(thePlayer, cmd, ...)
    local accName = getAccountName ( getPlayerAccount ( thePlayer) ) -- get his account name
    if isObjectInACLGroup ("user."..accName, aclGetGroup ( "Console") ) then

    local message = table.concat({...}, " ")

    triggerClientEvent(thePlayer, 'NotifyPol', thePlayer, getPlayerName(thePlayer), message )
    end
end)

function msgBox(player, text, type)
    triggerClientEvent(player, "AC-MsgBox", root, text, type)
end