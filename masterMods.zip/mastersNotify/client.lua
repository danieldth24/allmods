local x, y = guiGetScreenSize()
local link = "http://mta/"..getResourceName(getThisResource()).."/web-side/index.html"
local browser = createBrowser(x, y, true, true, false)



addEventHandler("onClientBrowserCreated", browser, function()
   loadBrowserURL(source, link)
   triggerEvent( "loadBrowserFunctions", getRootElement( ), browser )
   SendNUIMessage(browser, { action = "showAll" })
end)


function SendNUIMessage(browser, table)
   if isElement(browser) and type(table) == "table" then
      return executeBrowserJavascript(browser, 'window.postMessage('..toJSON(table)..'[0])')
   end
end

function dxNUI()

    dxDrawImage(0, 0, x, y, browser)

end
addEventHandler('onClientRender', getRootElement(), dxNUI) 


addEvent('AC-MsgBox', true)
addEventHandler("AC-MsgBox", getRootElement(), function(mensagem,css,timer,position)
	if not timer or timer == "" then
		timer = 10000
	end

	SendNUIMessage(browser, { css = css, mensagem = mensagem, timer = timer, position = position })
end)



addEvent("NotifyPol", true)
addEventHandler("NotifyPol", getRootElement(), function(nomeadm, mensagem)

	SendNUIMessage(browser, { css = "aviso", mensagem = ""..mensagem.."<br>Comunicado de: <b> "..nomeadm.."</b>", timer = 60000, position = "center" })
   
end)

