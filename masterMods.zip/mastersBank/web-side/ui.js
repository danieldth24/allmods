function addGaps(nStr) {
    nStr += '';
    var x = nStr.split('.');
    var x1 = x[0];
    var x2 = x.length > 1 ? '.' + x[1] : '';
    var rgx = /(\d+)(\d{3})/;
    while (rgx.test(x1)) {
        x1 = x1.replace(rgx, '$1' + '<span style="margin-left: 3px; margin-right: 3px;"/>' + '$2');
    }
    return x1 + x2;
}

function addCommas(nStr) {
    nStr += '';
    var x = nStr.split('.');
    var x1 = x[0];
    var x2 = x.length > 1 ? '.' + x[1] : '';
    var rgx = /(\d+)(\d{3})/;
    while (rgx.test(x1)) {
        x1 = x1.replace(rgx, '$1' + '.<span style="margin-left: 0px; margin-right: 1px;"/>' + '$2');
    }
    return x1 + x2;
}

$(document).ready(function() {
    window.addEventListener('message', function(event) {
        var item = event.data;
        $('.identidade').html(item.identidade);
        $('#salario').html(item.salario)



        if (item.openBank == true) {
            $(".container").fadeIn();
            $('.currentBalance').html(' ' + addCommas(item.bank));
            $('.carteira').html(' ' + addCommas(item.cart));
            



        }

        if (item.updateBalance == true) {
            $('.currentBalance').html(' ' + event.data.bank);
            $('.carteira').html(' ' + event.data.cart );
        }

        if (item.openBank == false) {
            $(".container").fadeOut();
        }
    });

    document.onkeyup = function(data) {
        if (data.which == 27) {
            mta.triggerEvent('closeBank')
        }
    };

    $("#SaqueRapido").click(function() {
        mta.triggerEvent('saqueBank', 100 )
    });
	
	$("#SaqueRapido1").click(function() {
        mta.triggerEvent('saqueBank', 500 )
    });
	
	$("#SaqueRapido2").click(function() {
        mta.triggerEvent('saqueBank', 1000 )
    });
	
	$("#SaqueRapido3").click(function() {
        mta.triggerEvent('saqueBank', 5000 )
    });

    $("#depositRapido1").click(function() {
        mta.triggerEvent('depositBank', 100 )
    });

    $("#depositRapido").click(function() {
        mta.triggerEvent('depositBank', 1000 )
    });

    $("#depositRapido2").click(function() {
        mta.triggerEvent('depositBank', 10000 )
    });

    $("#depositRapido3").click(function() {
        mta.triggerEvent('depositBank', 100000 )
    });

    $("#saque").submit(function(e) {
        e.preventDefault();

        //console.log("SACOU")

        $("#saque #amount").prop('disabled', false)
        var quantia = $("#saque #amount").val()
        mta.triggerEvent('saqueBank', quantia )

        setTimeout(function() {
            $("#sacar #amount").prop('disabled', false);
            $("#sacar #submit").css('display', 'block');
        }, 2000)

    });

    $("#depositar").submit(function(e) {
        e.preventDefault();


        var quantia = $("#depositar #amount").val()
        mta.triggerEvent('depositBank', quantia )

        setTimeout(function() {
            $("#depositar #amount").prop('disabled', false);
            $("#depositar #submit").css('display', 'block');
        }, 2000)

    });


    $("#trans").submit(function(e) {
        e.preventDefault();


        var quantia = $("#trans #amount").val()
        var id = $("#trans #toPlayer").val()
        mta.triggerEvent('transBank', quantia, id )

        setTimeout(function() {
            $("#depositar #amount").prop('disabled', false);
            $("#depositar #submit").css('display', 'block');
        }, 2000)

    });

    $("#multas").submit(function(e) {
        e.preventDefault();

        //console.log("DEPOSITOU")

        $("#multas #amount").prop('disabled', false)
        $.post('http://vrp_banco/multasSubmit', JSON.stringify({
            amount: $("#multas #amount").val()
        }));

        setTimeout(function() {
            $("#multas #amount").prop('disabled', false);
            $("#multas #submit").css('display', 'block');
        }, 2000)

    });

});

window.addEventListener('message', function(event) {
    var item = event.data;
    if (item.emprego != "") {
        $("#emprego").html(item.emprego)
    }
})

$("#icon1").click(function(){

    $("#icon1").addClass("icon_active");
    $("#icon2").removeClass("icon_active");
    $("#icon3").removeClass("icon_active");
    $("#icon4").removeClass("icon_active");

})

$("#icon2").click(function(){

    $("#icon2").addClass("icon_active");
    $("#icon1").removeClass("icon_active");
    $("#icon3").removeClass("icon_active");
    $("#icon4").removeClass("icon_active");

})

$("#icon3").click(function(){

    $("#icon3").addClass("icon_active");
    $("#icon1").removeClass("icon_active");
    $("#icon2").removeClass("icon_active");
    $("#icon4").removeClass("icon_active");

})

$("#icon4").click(function(){

    $("#icon4").addClass("icon_active");
    $("#icon3").removeClass("icon_active");
    $("#icon2").removeClass("icon_active");
    $("#icon1").removeClass("icon_active");

})


$("#potato1").click(function(){


    $("#icon2").addClass("icon_active");
    $("#icon1").removeClass("icon_active");
    $("#icon3").removeClass("icon_active");
    $("#icon4").removeClass("icon_active");

    

})

$("#potato2").click(function(){


    $("#icon3").addClass("icon_active");
    $("#icon1").removeClass("icon_active");
    $("#icon2").removeClass("icon_active");
    $("#icon4").removeClass("icon_active");

})

$("#potato3").click(function(){

    $("#icon4").addClass("icon_active");
    $("#icon3").removeClass("icon_active");
    $("#icon2").removeClass("icon_active");
    $("#icon1").removeClass("icon_active");

})




window.addEventListener('message', function(event) {
    var item = event.data;
    let banco_data = item.banco
    if (item.extrato === true) {
        $("#extrato").append(`
        <div class="item">
            <div class="icon"><i class="far fa-chart-line"></i></div>
            <div class="item-text">
                <label>Evento</label><br>
                <span>`+ item.tipo +`</span>
            </div>
            <div class="item-text-price">
                <label style="color: #92DBAC;">` + item.quantia + `</label><br>
                <span>` + item.quantia + `</span>
            </div>
        </div>
    `);
    }
})