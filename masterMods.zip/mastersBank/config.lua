
Config = {

    Dinheiro_Inicial = 2000,

    ElementData_Profissao = "Emprego",

    bind = "E",

    ['InfoServer'] = function(player, type, msg)

        triggerClientEvent(player, "Notify", player, type, msg)    

    end,



    Banks = {

        ["Banco 1"] = {
            Position = {-2425.67578, -594.30206, 132.28427 -1, "cylinder", 2.0, 255, 100, 100, 255 },
        }, 

        ["Banco 2"] = {
            Position = {1193.6370849609,-1321.5360107422,13.3984375 -1, "cylinder", 2.0, 255, 100, 100, 255 },
        },


    }
}