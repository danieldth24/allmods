local x, y = guiGetScreenSize()
local link = "http://mta/"..getResourceName(getThisResource()).."/web-side/ui.html"
local browser = createBrowser(x, y, true, true, false)
local oppened = false


 function SendNUIMessage(browser, table)
    if isElement(browser) and type(table) == "table" then
       return executeBrowserJavascript(browser, 'window.postMessage('..toJSON(table)..'[0])')
    end
 end


 function dxNUI()

    dxDrawImage(0, 0, x, y, browser)

    local bank = getElementData(localPlayer, 'shortBank')

    local emprego = getElementData(localPlayer, Config.ElementData_Profissao) or "Desempregado"
    SendNUIMessage(browser, {
        bank = bank,
        emprego = emprego,
        cart = getPlayerMoney(localPlayer),
        updateBalance= true,
    })

end




addEvent('openBank', true)
addEventHandler('openBank', getRootElement(), function()

    if oppened == false then

        addEventHandler('onClientRender', getRootElement(), dxNUI)
        oppened = true 
        triggerServerEvent('updateBankMoney', getRootElement(), localPlayer)


        triggerEvent('update', getRootElement() )
        local bank = getElementData(localPlayer, 'shortBank')
        SendNUIMessage(browser, {
            openBank = true,
            updateBalance= true,
            bank = bank,
            cart = getPlayerMoney(localPlayer),
            identidade = getPlayerName(localPlayer),
        })
        focusBrowser(browser)
        showCursor(true)
    else
        removeEventHandler('onClientRender', getRootElement(), dxNUI)
        oppened = false
        SendNUIMessage(browser, {openBank = false})
        showCursor(false)
    end
end)

addEvent('closeBank', true)
addEventHandler('closeBank', getRootElement(), function()

    removeEventHandler('onClientRender', getRootElement(), dxNUI)
    oppened = false
    SendNUIMessage(browser, {openBank = false})
    showCursor(false)
    triggerServerEvent('updateBankMoney', getRootElement(), localPlayer, quantia)

    SendNUIMessage(browser, {
        bank = bank,
        cart = getPlayerMoney(localPlayer),
    })

end)





local dxfont0_BebasNeueRegular = dxCreateFont("web-side/assets/BebasNeue-Regular.ttf", 26)
local screenW, screenH = guiGetScreenSize()
local renderText = false


function text()
    if oppened == false then
        dxDrawText("Pressione #DC143C[E] #FFFFFFPara abrir o banco.", screenW * 0.4234, screenH * 0.9065, screenW * 0.5766, screenH * 0.9491, tocolor(255, 255, 255, 255), 1.00, dxfont0_BebasNeueRegular, "left", "top", false, false, false, true, true)
    elseif oppened == true then 
        dxDrawText("Pressione #DC143C[E] #FFFFFFPara fechar o banco.", screenW * 0.4234, screenH * 0.9065, screenW * 0.5766, screenH * 0.9491, tocolor(255, 255, 255, 255), 1.00, dxfont0_BebasNeueRegular, "left", "top", false, false, false, true, true)
    end
end

addEvent('text', true)
addEventHandler('text', getRootElement(), function()

    if renderText == false then 

        addEventHandler('onClientRender', getRootElement(), text)
        renderText = true

    else

        removeEventHandler('onClientRender', getRootElement(), text)
        renderText = false

    end

end)



addEvent('saqueBank', true)
addEventHandler('saqueBank', getRootElement(), function(quantia)

    triggerServerEvent('saque', getRootElement(), localPlayer, quantia)
    triggerServerEvent('updateBankMoney', getRootElement(), localPlayer, quantia)

    SendNUIMessage(browser, {
        bank = bank,
        cart = getPlayerMoney(localPlayer),
        updateBalance= true,
    })

end)

addEvent('transBank', true)
addEventHandler('transBank', getRootElement(), function(quantia, id)

    triggerServerEvent('trans', getRootElement(), localPlayer, quantia, id)
    triggerServerEvent('updateBankMoney', getRootElement(), localPlayer, quantia)

    SendNUIMessage(browser, {
        bank = bank,
        cart = getPlayerMoney(localPlayer),
        updateBalance= true,
    })


end)

addEvent('depositBank', true)
addEventHandler('depositBank', getRootElement(), function(quantia)

    triggerServerEvent('deposit', getRootElement(), localPlayer, quantia)
    triggerServerEvent('updateBankMoney', getRootElement(), localPlayer, quantia)

    SendNUIMessage(browser, {
        bank = bank,
        cart = getPlayerMoney(localPlayer),
        updateBalance= true,
    })
    

end)




function split(pString, pPattern)
    local Table = {}  -- NOTE: use {n = 0} in Lua-5.0
    local fpat = "(.-)" .. pPattern
    local last_end = 1
    local s, e, cap = pString:find(fpat, 1)
    while s do
       if s ~= 1 or cap ~= "" then
      table.insert(Table,cap)
       end
       last_end = e+1
       s, e, cap = pString:find(fpat, last_end)
    end
    if last_end <= #pString then
       cap = pString:sub(last_end)
       table.insert(Table, cap)
    end
    return Table
 end






addEventHandler("onClientBrowserCreated", browser, function()
    loadBrowserURL(source, link)
end)



 addEventHandler("onClientCursorMove", root,
    function (relativeX, relativeY, absoluteX, absoluteY)
        injectBrowserMouseMove(browser, absoluteX, absoluteY)
    end
)


addEventHandler("onClientClick", root,
    function(button, state)
        if state == "down" then
            injectBrowserMouseDown(browser, button)
        else
            injectBrowserMouseUp(browser, button)
        end
    end
)






