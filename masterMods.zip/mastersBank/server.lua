connect = dbConnect('sqlite', 'Masters.db')

dbExec(connect, "CREATE TABLE IF NOT EXISTS Banco (Account TEXT,Dinheiro TEXT )")


for i, v in pairs(Config.Banks) do

    local marker = createMarker(v.Position[1], v.Position[2], v.Position[3], v.Position[4], v.Position[5], v.Position[6], v.Position[7], v.Position[8] )

    function openBank(player) 
        
       triggerClientEvent(player, 'openBank', player )

    end

    function closeBank(player) 
        
        triggerClientEvent(player, 'closeBank', player )
 
     end

    addEventHandler('onMarkerHit', marker, function(player)

        if getElementType(player) == "player" then 
    
        bindKey(player, Config.bind, 'down', openBank)
        unbindKey(player, Config.bind, 'down', closeBank )
        toggleControl(player, "aim_weapon", false)
        toggleControl(player, "next_weapon", false)
        toggleControl(player, "previous_weapon", false)
        triggerClientEvent(player, 'text', player )
        end
    end)

    addEventHandler("onMarkerLeave", marker, function(player)

        if getElementType(player) == "player" then
    
        unbindKey(player, Config.bind, 'down', openBank )
        bindKey(player, Config.bind, 'down', closeBank )
        toggleControl(player, "aim_weapon", true)
        toggleControl(player, "next_weapon", true)
        toggleControl(player, "previous_weapon", true)
        triggerClientEvent(player, 'text', player )
        
        end
    end)

end

addEventHandler('onPlayerLogin', root, function(accountaa, account)
local accountName = getAccountName(account)
local result = dbPoll(dbQuery(connect, "SELECT * FROM Banco WHERE Account=?", tostring(accountName) ), -1) 
local result = result[1] 

    if not result then 

        dbExec(connect, "INSERT INTO Banco (Account, Dinheiro,Extrato) VALUES (?,?,?)", accountName, Config.Dinheiro_Inicial, toJSON ( {} ) ) -- registra o usuario na database

    end
end)

function deposit(player, quantia)
local money = getPlayerMoney(player)
local account = getPlayerAccount(player)
local accountName = getAccountName(account)

local result = dbPoll(dbQuery(connect, "SELECT * FROM Banco WHERE Account=?", tostring(accountName) ), -1) 
local result = result[1] 

    if accountName and result and money >= tonumber(quantia) and quantia ~= "" then 

        takePlayerMoney(player, quantia)

        dbExec(connect, "UPDATE Banco SET Dinheiro=? WHERE Account=?", result.Dinheiro + quantia, accountName ) -- troca a whitelist do id para "false"

        setElementData(player, "shortBank", result.Dinheiro)
        Config["InfoServer"](player, 'verde', "Você depositou R$"..quantia)

        else

            Config["InfoServer"](player, 'azul', 'Você não tem dinheiro o suficiente.')
            
     end
end
addEvent('deposit', true)
addEventHandler('deposit', getRootElement(), deposit)

function saque(player, quantia)
    local money = getPlayerMoney(player)
    local account = getPlayerAccount(player)
    local accountName = getAccountName(account)
    
    local result = dbPoll(dbQuery(connect, "SELECT * FROM Banco WHERE Account=?", tostring(accountName) ), -1) 
    local result = result[1] 
    
        if accountName and result and tonumber(result.Dinheiro) >= tonumber(quantia) and quantia ~= "" then 
    
            givePlayerMoney(player, quantia)
    
            dbExec(connect, "UPDATE Banco SET Dinheiro=? WHERE Account=?", result.Dinheiro - quantia, accountName ) -- troca a whitelist do id para "false"
    
            setElementData(player, "shortBank", result.Dinheiro)

            Config["InfoServer"](player, 'verde', "Você sacou R$"..quantia)
    
        else

            Config["InfoServer"](player, 'azul', 'Você não tem essa quantia.')
                
         end
    end

addEvent('saque', true)
addEventHandler('saque', getRootElement(), saque)




function getPlayerID(id)
    v = false
    for i, player in ipairs (getElementsByType("player")) do
      if getElementData(player, "ID") == id then
        v = player
        break
      end
    end
    return v
  end

function trans(player, quantia, id)
    local money = getPlayerMoney(player)
    local account = getPlayerAccount(player)
    local accountName = getAccountName(account)

    local player2 = getPlayerID(tonumber(id))

    if player2 and player ~= player2 and tonumber(quantia) then


    local account2 = getPlayerAccount(player2)
    local accountName2 = getAccountName(account2)

    
    local result = dbPoll(dbQuery(connect, "SELECT * FROM Banco WHERE Account=?", tostring(accountName) ), -1) 
    local result = result[1] 


    local result2 = dbPoll(dbQuery(connect, "SELECT * FROM Banco WHERE Account=?", tostring(accountName2) ), -1) 
    local result2 = result2[1] 
    
        if accountName and result and accountName2 and result2 and tonumber(result.Dinheiro) >= tonumber(quantia) then 
    
    
            dbExec(connect, "UPDATE Banco SET Dinheiro=? WHERE Account=?", result.Dinheiro - quantia, accountName )

            dbExec(connect, "UPDATE Banco SET Dinheiro=? WHERE Account=?", result2.Dinheiro + quantia, accountName2 )


            setElementData(player, "shortBank", result.Dinheiro)

            setElementData(player2, "shortBank", result2.Dinheiro)

            Config["InfoServer"](player, 'verde', "Você transferiu R$"..quantia.." para o id: "..id)
            local id2 = getElementData(player, "ID")
            Config["InfoServer"](player2, 'verde', "Você recebeu R$"..quantia.." do id: "..id2)
    
            else

                Config["InfoServer"](player, 'azul', 'Você não tem essa quantia.')

            end

        else

            Config["InfoServer"](player, 'azul', 'Esse player não está online.')

         end
    end

addEvent('trans', true)
addEventHandler('trans', getRootElement(), trans)


function updateBankMoney( player )
    local account = getPlayerAccount(player)
    local accountName = getAccountName(account)
    local result = dbPoll(dbQuery(connect, "SELECT * FROM Banco WHERE Account=?", tostring(accountName) ), -1) 
    local result = result[1] 
    setElementData(player, "shortBank", result.Dinheiro)
end
addEvent('updateBankMoney', true)
addEventHandler('updateBankMoney', getRootElement(), updateBankMoney)