ElementData_Banco = "TS:Bancobb"
ElementData_Emprego = "Emprego"
ElementData_Vip = "VIPC"
ElementData_Level = "Level"

