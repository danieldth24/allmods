local x, y = guiGetScreenSize()
local link = "http://mta/"..getResourceName(getThisResource()).."/web-side/index.html"
local browser = createBrowser(x, y, true, true, false)


setDevelopmentMode(true, true)

addEventHandler("onClientBrowserCreated", browser, function()
   loadBrowserURL(source, link)
end)


function SendNUIMessage(browser, table)
   if isElement(browser) and type(table) == "table" then
      return executeBrowserJavascript(browser, 'window.postMessage('..toJSON(table)..'[0])')
   end
end



function dxNUI()

    dxDrawImage(0, 0, x, y, browser)

    SendNUIMessage(browser, {din = getPlayerMoney(localPlayer), banco = getElementData(localPlayer, ElementData_Banco ) or 0,  vip = getElementData(localPlayer, ElementData_Vip ) or 0, level = getElementData(localPlayer, ElementData_Level) or 0  })

end
addEventHandler('onClientRender', getRootElement(), dxNUI) 




