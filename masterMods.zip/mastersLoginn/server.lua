database = dbConnect( "sqlite", "assets/database/database.db" )

function Login(Player, User, Pass, Avatar)
    if User ~ "" and Pass ~ "" then 
        dbExec( connection, "INSERT INTO table_name VALUES (User,Pass,Avatar)", User, Pass, Number(Avatar) )
    else
        Notify(Player, "Voce Precisa Preencher todos os Campos")     
    end
end