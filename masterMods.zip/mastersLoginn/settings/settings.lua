

local Settings = {
    ['Ajustes'] = {
        ['showCursor'] = true; -- Caso queira que o cursor aparece no login use ( true ) caso ao contrario ( false ) Recomendado: true
        ['logo'] = "assets/images/logo.png",
        ['background_login'] = "assets/images/background_login.png"
    

    };

    ['Notify'] = {
        message_server = function (player, message, type)
            exports['INFO']:addNotifY(player, message, type)
        end;

        message_client = function (message, type)
            exports['INFO']:addNotifY(message, type)
        end;
    };
}


function getSettings ()
    return Settings
end