

addCommandHandler( "dv", function (player, ...)
	if ... then
		
	destroyElement(isPedDrivingVehicle (player))
end)






--
--		Uteis
--
--

function isPedDrivingVehicle(ped)
    assert(isElement(ped) and (getElementType(ped) == "ped" or getElementType(ped) == "player"), "Bad argument @ isPedDrivingVehicle [ped/player expected, got " .. tostring(ped) .. "]")
    local isDriving = isPedInVehicle(ped) and getVehicleOccupant(getPedOccupiedVehicle(ped)) == ped
    return isDriving, isDriving and getPedOccupiedVehicle(ped) or nil
end

function getPlayerId(player)
	getElementData(player, "playerID")
end