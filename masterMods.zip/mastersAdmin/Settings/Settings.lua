

Settings = {

    ["AclStaffs"] = {
        "Console",
        "Admin",
        "SuperModerator",
        "Moderator",
        "CoFundador",
        "Desenvolvedor",
        "Moderador",
        "Suporte",
    },

    ["Comandos"] = {
        ["dv"] = {"Console", "Admin", "SuperModerator", "Moderator", "CoFundador", "Desenvolvedor", "Moderador", "Suporte"} -- ["comando"] = {"Cargos que podem executa-lo."}
    }

}