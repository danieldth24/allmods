$(document).ready(function(){

	window.addEventListener("message",function(event){
		if (event["data"]["action"] !== undefined){
			if (event["data"]["action"] == true){
                $("body").show()
				$("#displayArsenal").fadeIn(500);
			} else {
				$("#displayArsenal").fadeOut(500);
                $("body").hide()
			}

			return
		}
    });

    window.addEventListener("message",function(event){
        if (event["data"]["update"] !== undefined){
            if (event["data"]["update"] == true){
    
            var html = $(`<div class="bloco" id="bloco`+event.data.n + `"> <span class="texto-arma">`+ event.data.name +`</span> <img src="`+ event.data.url + `" alt=""> <div id="btn`+event.data.n + `" class="btn-give"> PEGAR </div></div>`)
    
            $("#blocos").append(html);
    
            $("#btn"+event.data.n + "").click(function(){
    
                mta.triggerEvent('clickopenArsenal'+ event.data.n + "", event.data.v3, event.data.v4, event.data.type, event.data.perm)
    
            })
    
            } else {
                $("#blocos").html('')
            }
            
        }
    })

    $(".close").click(function(){
    
        mta.triggerEvent('close')

    })


    $(".remove").click(function(){
    
        mta.triggerEvent('takA')

    })


    $(".shield").click(function(){
    
        mta.triggerEvent('colete')

    }) 

});