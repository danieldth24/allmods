Config = {
    Arsenais = { 

        ["Policia"] = {
            Position = {2495.53955, -1614.41162, 16.87682 -1, "cylinder", 2.0, 221, 51, 221, 255},
            Dimension = 0,
            Interior = 0,
            Armas = {
                {"Cassetete","images/cass.png", 3, 1, "ACL", "Everyone" }, -- Nome, url_da_imagem, id_da_arma, quantidade
                {"Colt 45","images/colt.png", 22, 1, "ACL", "Everyone" }, -- Nome, url_da_imagem, id_da_arma, quantidade
                {"Deagle","images/deagle.png", 24, 1, "ACL", "Everyone" }, -- Nome, url_da_imagem, id_da_arma, quantidade
                {"M4A1","images/m4a1.png", 31, 1000, "ACL", "Everyone" }, -- Nome, url_da_imagem, id_da_arma, quantidade
                {"M4A1","images/m4a1.png", 31, 1000, "ACL", "Everyone" }, -- Nome, url_da_imagem, id_da_arma, quantidade
                {"M4A1","images/m4a1.png", 31, 1000, "ACL", "Everyone" }, -- Nome, url_da_imagem, id_da_arma, quantidade
                {"M4A1","images/m4a1.png", 31, 1000, "ACL", "Everyone" }, -- Nome, url_da_imagem, id_da_arma, quantidade
                {"M4A1","images/m4a1.png", 31, 1000, "ACL", "Everyone" }, -- Nome, url_da_imagem, id_da_arma, quantidade
                {"M4A1","images/m4a1.png", 31, 1000, "ACL", "Everyone" }, -- Nome, url_da_imagem, id_da_arma, quantidade
                {"M4A1","images/m4a1.png", 31, 1000, "ACL", "Everyone" }, -- Nome, url_da_imagem, id_da_arma, quantidade
                
            }
        },


        ["Potato"] = {
            Position = {1184.6174316406,-1321.8413085938,13.573609352112 -1, "cylinder", 2.0, 221, 51, 221, 255},
            Dimension = 0,
            Interior = 0,
            Armas = {
                {"FA","imag3es/ca3ss.png", 3, 1, "ACL", "Everyone" }, -- Nome, url_da_imagem, id_da_arma, quantidade
                {"FEE","im3ages/c3olt.png", 22, 1, "ACL", "Everyone" }, -- Nome, url_da_imagem, id_da_arma, quantidade
                {"FO","ima6zges/de3agle.png", 24, 1, "ACL", "Everyone" }, -- Nome, url_da_imagem, id_da_arma, quantidade
                {"FU","ima3ges/m43a1.png", 31, 1000, "ACL", "Everyone" }, -- Nome, url_da_imagem, id_da_arma, quantidade
                
            }
        },



    }
}