local x, y = guiGetScreenSize()
local link = "http://mta/"..getResourceName(getThisResource()).."/web-side/index.html"
local browser = createBrowser(x, y, true, true, false)
local openned = false


addEventHandler("onClientBrowserCreated", browser, function()
    loadBrowserURL(source, link)
    focusBrowser(browser)
 end)


 
 
 function SendNUIMessage(browser, table)
    if isElement(browser) and type(table) == "table" then
       return executeBrowserJavascript(browser, 'window.postMessage('..toJSON(table)..'[0])')
    end
 end


 function dxNUI()

    dxDrawImage(0, 0, x, y, browser)


end

function give(v1, v2, type, perm)
            
    triggerServerEvent('giveWeapon', getRootElement(), localPlayer, v1, v2, type, perm)

 end


addEvent('openArsenal', true)
addEventHandler('openArsenal', getRootElement(), function(table)
   if (openned == false) then
      addEventHandler('onClientRender', getRootElement(), dxNUI) 
      SendNUIMessage(browser, {action = true})
      for i, v in ipairs(table) do 

         SendNUIMessage(browser, {update = true, n = i, name = v[1], url = v[2], v3 = v[3], v4 = v[4], type = v[5], perm = v[6] })
         showCursor(true)


         addEvent('clickopenArsenal'..i.."", true)
         addEventHandler('clickopenArsenal'..i.."", getRootElement(), give)
      end
      openned = true
   else
      removeEventHandler('onClientRender', getRootElement(), dxNUI) 
      SendNUIMessage(browser, {action = false})
      openned = false
      SendNUIMessage(browser, {update = false})
      showCursor(false)
      for i, v in ipairs(table) do 
        removeEventHandler('clickopenArsenal'..i.."", getRootElement(), give)
      end
   end

   bindKey('backspace', 'down', function()

    if (openned == true) then 
       removeEventHandler('onClientRender', getRootElement(), dxNUI) 
       SendNUIMessage(browser, {action = false})
       SendNUIMessage(browser, {update = false})
       openned = false
       showCursor(false)
       for i, v in ipairs(table) do 
         removeEventHandler('clickopenArsenal'..i.."", getRootElement(), give)
       end
    end
 end)


 addEvent('close', true)
 addEventHandler('close', getRootElement(), function()

    if (openned == true) then 
       removeEventHandler('onClientRender', getRootElement(), dxNUI) 
       SendNUIMessage(browser, {action = false})
       SendNUIMessage(browser, {update = false})
       openned = false
       showCursor(false)
       for i, v in ipairs(table) do 
         removeEventHandler('clickopenArsenal'..i.."", getRootElement(), give)
       end
    end
 end)

end)



addEvent('takA', true)
addEventHandler('takA', getRootElement(),
function ()
           
   triggerServerEvent('take', getRootElement(), localPlayer)
   triggerEvent("Notify", localPlayer, "verde", "Você Removeu suas armas!")

end)

addEvent('colete', true)
addEventHandler('colete', getRootElement(),
function ()
           
   setPedArmor ( localPlayer, 100 )
   triggerEvent("Notify", localPlayer, "verde", "Você pegou o colete!")

end)


addEventHandler("onClientBrowserCreated", browser, function()
   loadBrowserURL(source, link)
   addEventHandler("onClientKey", root, onKey)
end)



addEventHandler("onClientCursorMove", root,
   function (relativeX, relativeY, absoluteX, absoluteY)
       injectBrowserMouseMove(browser, absoluteX, absoluteY)
   end
)


addEventHandler("onClientClick", root,
   function(button, state)
       if state == "down" then
           injectBrowserMouseDown(browser, button)
       else
           injectBrowserMouseUp(browser, button)
       end
   end
)


function onKey(button)
   if button == "mouse_wheel_down" then
       injectBrowserMouseWheel(browser, -90, 0)
   elseif button == "mouse_wheel_up" then
       injectBrowserMouseWheel(browser, 90, 0)
   end
end