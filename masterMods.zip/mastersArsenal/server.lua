for i, v in pairs(Config.Arsenais) do

    marker = createMarker(v.Position[1], v.Position[2], v.Position[3], v.Position[4], v.Position[5], v.Position[6],v.Position[7],v.Position[8],v.Position[9])
    setElementInterior(marker, v.Interior)
    setElementDimension(marker, v.Dimension)
    addEventHandler("onMarkerHit", marker, 
    function(player)

        triggerClientEvent(player, 'openArsenal', player, v.Armas)

    end)

end

addEvent('giveWeapon', true)
addEventHandler('giveWeapon', getRootElement(), function(player, id, qnt, type, perm)

    if type == 'ElementData' then 
        if getElementData(player, perm) then 

            giveWeapon(player, id, qnt)
            triggerClientEvent(player, "Notify", player, "verde", "Você pegou o armamento.")    
            
        else

            triggerClientEvent(player, "Notify", player, "vermelho", "Você não tem permissão pra pegar esse armamento.")    

        end

    local accName = getAccountName ( getPlayerAccount ( player ) ) 

    elseif type == 'ACL' then 

    local accName = getAccountName ( getPlayerAccount ( player ) ) -- get his account name
    if isObjectInACLGroup ("user."..accName, aclGetGroup ( perm ) ) then

        giveWeapon(player, id, qnt)
        triggerClientEvent(player, "Notify", player, "verde", "Você pegou o armamento.")    
        
    else

        triggerClientEvent(player, "Notify", player, "vermelho", "Você não tem permissão pra pegar esse armamento.")   
        
        end 

    end

end)

addEvent('take', true)
addEventHandler('take', getRootElement(), function(player)

    takeAllWeapons ( player )

end)